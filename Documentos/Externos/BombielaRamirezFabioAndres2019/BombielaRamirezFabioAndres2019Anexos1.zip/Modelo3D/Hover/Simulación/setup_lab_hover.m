
clc
clear all;
%
% Amplifier Configuration
% Amplifier gain used for yaw and pitch axes.
K_AMP = 3;
% Amplifier Maximum Output Voltage (V)
VMAX_AMP = 24;
% Digital-to-Analog Maximum Voltage (V): set to 10 for Q4/Q8 cards
VMAX_DAC = 10;
%
% Filter and Rate Limiter Settings
% Specifications of a second-order low-pass filter
wcf = 2 * pi * 20; % filter cutting frequency
zetaf = 0.6;        % filter damping ratio
%
% Maximum Rate of Desired Position (rad/s)
% Note: This is for both the program and joystick commands.
CMD_RATE_LIMIT = 60 * pi/180; % 60 deg/s converted to rad/s
%
% Joystick Settings
% Joystick input X sensitivity used for roll (deg/s/V)
K_JOYSTICK_X = -25;
% Joystick input Y sensitivity used for pitch (deg/s/V)
K_JOYSTICK_Y = 25;
% Pitch integrator saturation of joystick (deg)
INT_JOYSTICK_SAT_LOWER = -10;
INT_JOYSTICK_SAT_UPPER = 10;
% Deadzone of joystick: set input ranging from -DZ to +DZ to 0 (V)
JOYSTICK_X_DZ = 0.25;
JOYSTICK_Y_DZ = 0.25;
%
%
%Set the model parameters of the 3DOF HOVER.
% These parameters are used for model representation and controller design.
[ Kt, Kf, L, Jy, Jp, Jr, g, K_EC_Y , K_EC_P , K_EC_R ] = config_hover();
%
% For the following state vector: X = [ theta; psi; theta_dot; psi_dot]
% Initialization the state-Space representation of the open-loop System
HOVER_ABCD_eqns;
%
% Design LQR Controller
% Bias voltage applied to motors (V)
V_bias = 2.0;
% LQR Controller Design Specifications
Q = diag([500 350 350 0 20 20] );
R = 0.01*diag([1 1 1 1]);
% Automatically calculate the LQR controller gain
%$K = lqr( A, B, Q, R );    
% Display the calculated gains
r=1;


A=[0 0 0 1 0 0;
    0 0 0 0 1 0;
    0 0 0 0 0 1;
    0 0 0 0 0 0;
    0 0 0 0 0 0;
    0 0 0 0 0 0];

C=[1 0 0 0 0 0;
    0 1 0 0 0 0;
    0 0 1 0 0 0];
D=0;

B=[0 0 0 0;
    0 0 0 0;
    0 0 0 0;
    -0.067275 -0.040753 0.062185 0.069679;
    0.26958 -0.19712 0 0;
    0 0 0.17155 -0.17676];


Q13=[-0.067275 -0.040753 0.062185 0.069679]*0.1104;
Q23=[0.26958 -0.19712 0 0]*0.0552;
Q33=[0 0 0.17155 -0.17676]*0.0552;
Q=[Q13;Q23;Q33];
H=Q'*inv(Q*Q');

%0.55 para Yaw
%0.61 para Pitch
%0.43 mpara Roll
%Pulso m�ximo de 0.1 N.m

sys=ss(A,B,C,D);
Gs1=tf(sys);


Jtp=0.0276;
l=0.1968;
Ixx=Jr;
Iyy=Jp;
Izz=Jy;
Kf=0.1188;
Km=0.0036;
K11=(Iyy-Izz)/Ixx;
K22=(Izz-Ixx)/Iyy;
K3=(Ixx-Iyy)/Izz;

K4=Jtp/Ixx;
K5=Jtp/Iyy;

b41=-0.067275;
b42=-0.040753;
b43=0.062185;
b44=0.069679;
b51=0.26958;
b52=-0.19712;
b53=0;
b54=0;
b61=0;
b62=0;
b63=0.17155;
b64=-0.17676;


% PRUEBA QUE SI FUNCIONA EN IMPLEMENTACI�N

A = [0 0 0 1 0 0;
    0 0 0 0 1 0;
    0 0 0 0 0 1;
    0 0 0 0 0 0;
    0 0 0 0 0 0;
    0 0 0 0 0 0];

C = [1 0 0 0 0 0;
    0 1 0 0 0 0;
    0 0 1 0 0 0];

D = zeros(3,3);

B = [0 0 0 0;
    0 0 0 0;
    0 0 0 0;
    -0.067275 -0.040753 0.062185 0.069679;
    0.26958 -0.19712 0 0;
    0 0 0.17155 -0.17676];


%Conversion de sistema de voltaje a torque

Q13=[-0.067275 -0.040753 0.062185 0.069679]*0.1104;
Q23=[0.26958 -0.19712 0 0]*0.0552;
Q33=[0 0 0.17155 -0.17676]*0.0552;
Q=[Q13;Q23;Q33];
T=Q'*inv(Q*Q');

Bn=B*T;



sys = ss(A,Bn,C,D);
[Ac,Bc,C,D] = ssdata(sys);

%Polos deseados

z = sym('z');
z1 = -10;
z2 = -20;
z3 = -40;
z4 = -50;
z5 = -10;
z6 = -30;

%Ubicaci�n de los polos deseados
Co = ctrb(Ac,Bc);
Ob = obsv(Ac,C);
K=place(Ac,Bc,[z1 z2 z3 z4 z5 z6]);
L=place(Ac',C',10*[z1 z2 z3 z4 z5 z6])';
Kg=inv(C*inv(-Ac+Bc*K)*Bc);


Mp=0.2;
ts=2;
zita=sqrt(((log(Mp)^2))/(((pi^2)+(log(Mp)^2))));
wn=4/(zita*ts);
Pd=(-zita*wn+1i*wn*sqrt(1-zita^2));


z1 = -2;
z2 = -3;
z3 = -5;
z4 = -5;
z5 = -6;
z6 = -3;
z7 = -4;
z8 = -7;
z9 = -8;

% z1 = -2; mejor respuesta hasta ahora
% z2 = -3;
% z3 = -5;
% z4 = -5;
% z5 = -6;
% z6 = -3;
% z7 = -4;
% z8 = -7;
% z9 = -7;

% z1 = -2; %Buena respuesta sin embargo tiene muchas oscilaciones
% z2 = -3;
% z3 = -5;
% z4 = -6;
% z5 = -7;
% z6 = -2;
% z7 = -7;
% z8 = -8;
% z9 = -9;
% 
% z1 = -2; Buena respuesta, reducci�n en oscilaciones- sistema lento
% z2 = -3;
% z3 = -5;
% z4 = -6;
% z5 = -7;
% z6 = -1;
% z7 = -7;
% z8 = -8;
% z9 = -9;

% z1 = -2; Respuesta brusca, saturaci�n en controladores, conclusi�n los
            %tiene que ser mayores a -9
% z2 = -3;
% z3 = -5;
% z4 = -6;
% z5 = -7;
% z6 = -1;
% z7 = -4;
% z8 = -9;
% z9 = -9;
% 
% z1 = -2;  Sistema lento, no es viable
% z2 = -3;
% z3 = -5;
% z4 = -6;
% z5 = -7;
% z6 = -0.1;
% z7 = -4;
% z8 = -9;
% z9 = -8;

Ki = eye(3);
Aa = [Ac zeros(6,3);C zeros(3,3)];


Ba = [Bc;D];
Ka = place(Aa,Ba,[z1 z2 z3 z4 z5 z6 z7 z8 z9]);
K1 = Ka(:,1:6)
Ki = Ka(:,7:9)
%Redise�o de sistema original


% Amplifier Configuration

K_AMP = 3;
VMAX_AMP = 24;
VMAX_DAC = 10;
CMD_RATE_LIMIT = 60 * pi/180; % 60 deg/s converted to rad/s
V_bias = 2.0;

% MOTORES


J = 1.91E-6;
b = 1.83E-6;
Kt = 18.2E-3;
Ri = 0.83;
Li = 0.63e-3;
Kb=18.2E-3;
s = tf('s');
P_motor = Kt/(((J*s+b)*(Li*s+Ri)+Kt*Kb));
[num,den]=tfdata(P_motor,'v');
sys_cl = feedback(P_motor,1);
step(sys_cl)
opt = stepDataOptions('StepAmplitude',1);
[y,t]=step((1/963.86)*P_motor,opt);
plot(t,y)

%torque de retroceso

kphi=2.147;
cphi=0.29;
ktheta=5.859;
ctheta=1.094;

%MPC

Kx =[-113.7929  168.4360   -2.2869  -78.7611  113.9368   -1.6067;
 -135.1049 -139.6761   -2.8009  -94.1203  -94.8936   -1.9809;
  159.4644   12.0908  178.5173  110.9067    8.4868  121.5201;
  160.3317   12.0987 -177.2872  111.3265    8.4780 -120.5180];


Ky = [-47.0221   70.2187   -0.9394;
  -55.6870  -58.1332   -1.1476;
   65.7702    4.9687   74.2436;
   66.1706    4.9753  -73.7705];


O=[1 0 0 0;
    0 1 0 0;
    0 0 1 0;
    0 0 0 1];
O=963.86*O;
inv(O)
