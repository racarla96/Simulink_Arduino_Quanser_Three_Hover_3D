% Simscape(TM) Multibody(TM) version: 6.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(71).translation = [0.0 0.0 0.0];
smiData.RigidTransform(71).angle = 0.0;
smiData.RigidTransform(71).axis = [0.0 0.0 0.0];
smiData.RigidTransform(71).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [-3.4500000000000002 0 0];  % cm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[ParteU-1:-:PiezaYaw2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [0.0015474792345155919 0.99999999999999112 9.4000000000000092];  % cm
smiData.RigidTransform(2).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(2).axis = [0.5773502691896254 0.57735026918962606 -0.57735026918962573];
smiData.RigidTransform(2).ID = 'F[ParteU-1:-:PiezaYaw2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-4.8249999999999984 9.3999999999999968 0.0015474792345065991];  % cm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = 'B[ParteU-1:-:PiezaRoll3-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-4.8749999999999902 -0.50000000000000266 5.3290705182007514e-15];  % cm
smiData.RigidTransform(4).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(4).axis = [0.57735026918962573 0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(4).ID = 'F[ParteU-1:-:PiezaRoll3-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-5 0.69999999999999996 -5.0000000000000044];  % cm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[Base2-1:-:base-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-5.0000000000173497 10.700000000000001 -5.0000000000000036];  % cm
smiData.RigidTransform(6).angle = 2.0943951023923781;  % rad
smiData.RigidTransform(6).axis = [0.57735026919017085 -0.57735026918935328 0.57735026918935328];
smiData.RigidTransform(6).ID = 'F[Base2-1:-:base-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [0 -2.4999999999999996 0];  % cm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[PiezaRoll3-2:-:PiezaRoll2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [-2.499999999999996 -7.7715611723760958e-16 -2.4424906541753444e-15];  % cm
smiData.RigidTransform(8).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(8).axis = [-0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(8).ID = 'F[PiezaRoll3-2:-:PiezaRoll2-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [8.2500000000000018 0.84999999999999798 -0.29999999999999888];  % cm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[PiezaRoll2-2:-:Superior-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [0.30000000000020055 0.49999999999999867 8.2374921777190124];  % cm
smiData.RigidTransform(10).angle = 3.1415926535895999;  % rad
smiData.RigidTransform(10).axis = [9.6866958898544908e-14 -0.70710678118654802 0.70710678118654713];
smiData.RigidTransform(10).ID = 'F[PiezaRoll2-2:-:Superior-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [0 0.80000000000000071 -17.747761326725616];  % cm
smiData.RigidTransform(11).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(11).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(11).ID = 'B[Superior-1:-:faninferior-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [6.9501272031693356e-14 3.1048155017549235e-14 -2.6210099518143326e-13];  % cm
smiData.RigidTransform(12).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(12).axis = [0.57735026918962584 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(12).ID = 'F[Superior-1:-:faninferior-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [17.747761326726124 0.80000000000000626 -4.9960036108132044e-13];  % cm
smiData.RigidTransform(13).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(13).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(13).ID = 'B[Superior-1:-:faninferior-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-9.5956278312159862e-14 1.0382803338388748e-14 -3.6816823768283077e-13];  % cm
smiData.RigidTransform(14).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(14).axis = [0.57735026918962584 -0.57735026918962562 0.57735026918962584];
smiData.RigidTransform(14).ID = 'F[Superior-1:-:faninferior-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [-17.747761326725119 0.80000000000000071 5.0792703376600912e-13];  % cm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(15).ID = 'B[Superior-1:-:faninferior-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [1.7332749411372288e-13 3.1293103306916989e-14 -1.7973788793158536e-13];  % cm
smiData.RigidTransform(16).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(16).axis = [0.57735026918962584 -0.57735026918962551 0.57735026918962595];
smiData.RigidTransform(16).ID = 'F[Superior-1:-:faninferior-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [1.0019762797242038e-12 0.80000000000000349 17.747761326725627];  % cm
smiData.RigidTransform(17).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(17).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(17).ID = 'B[Superior-1:-:faninferior-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [6.0540009509145499e-14 5.9642806857438286e-17 -7.9465613501753926e-13];  % cm
smiData.RigidTransform(18).angle = 1.5880305607638938;  % rad
smiData.RigidTransform(18).axis = [0.98291258732264852 -0.13015922111532602 0.13015922111532607];
smiData.RigidTransform(18).ID = 'F[Superior-1:-:faninferior-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [5.3426407495434578 1.0999999999999954 -7.3532915274183468];  % cm
smiData.RigidTransform(19).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(19).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(19).ID = 'B[faninferior-1:-:faninferior-7]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [-5.3425348937846753 1.100000000000005 -7.3533684372933532];  % cm
smiData.RigidTransform(20).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(20).axis = [-0.57735026918962584 -0.57735026918962562 -0.57735026918962584];
smiData.RigidTransform(20).ID = 'F[faninferior-1:-:faninferior-7]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [5.3426407495434534 1.1000000000000036 -7.3532915274183459];  % cm
smiData.RigidTransform(21).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(21).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(21).ID = 'B[faninferior-2:-:faninferior-8]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [-5.342534893783415 1.0999999999999948 -7.35336843729484];  % cm
smiData.RigidTransform(22).angle = 2.0943951023931966;  % rad
smiData.RigidTransform(22).axis = [-0.57735026918962629 -0.57735026918962529 -0.57735026918962584];
smiData.RigidTransform(22).ID = 'F[faninferior-2:-:faninferior-8]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [-8.644243621089748 1.0999999999999983 2.8092274178382226];  % cm
smiData.RigidTransform(23).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(23).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(23).ID = 'B[faninferior-3:-:faninferior-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [5.3426407495435413 1.1000000000000041 -7.3532915274203452];  % cm
smiData.RigidTransform(24).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(24).axis = [-0.57735026918962595 -0.57735026918962606 -0.5773502691896254];
smiData.RigidTransform(24).ID = 'F[faninferior-3:-:faninferior-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [0.00083465733535237341 1.100000000000001 9.0892632137721634];  % cm
smiData.RigidTransform(25).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(25).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(25).ID = 'B[faninferior-4:-:faninferior-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [-5.3425348937894732 1.1000000000000045 -7.3533684372960888];  % cm
smiData.RigidTransform(26).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(26).axis = [-0.57735026918962584 -0.57735026918962562 -0.57735026918962584];
smiData.RigidTransform(26).ID = 'F[faninferior-4:-:faninferior-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [-4.8249999999999984 9.3999999999999968 0.0015474792345065991];  % cm
smiData.RigidTransform(27).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(27).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(27).ID = 'B[ParteU-1:-:PiezaYaw-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [-7.1054273576010019e-15 -2.5358949488047329 -5.773159728050814e-15];  % cm
smiData.RigidTransform(28).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(28).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962562];
smiData.RigidTransform(28).ID = 'F[ParteU-1:-:PiezaYaw-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [-1.389105051195251 0 -1.0000000000000064];  % cm
smiData.RigidTransform(29).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(29).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(29).ID = 'B[PiezaRoll3-2:-:PiezaYaw-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [0.89087185423503046 0.95000000000000728 -0.67553485426871851];  % cm
smiData.RigidTransform(30).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(30).axis = [-0.57735026918962584 -0.57735026918962573 -0.57735026918962573];
smiData.RigidTransform(30).ID = 'F[PiezaRoll3-2:-:PiezaYaw-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [-4.8249999999999984 9.3999999999999968 0.0015474792345065991];  % cm
smiData.RigidTransform(31).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(31).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(31).ID = 'B[ParteU-1:-:PiezaYaw-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [6.2172489379008766e-15 5.776088919367691 0];  % cm
smiData.RigidTransform(32).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(32).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(32).ID = 'F[ParteU-1:-:PiezaYaw-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [0 0.95000000000000084 0];  % cm
smiData.RigidTransform(33).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(33).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(33).ID = 'B[PiezaYaw-2:-:PiezaRoll3-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [-0.048911080632300263 -0.4999999999999985 2.1649348980190553e-15];  % cm
smiData.RigidTransform(34).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(34).axis = [0.57735026918962573 0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(34).ID = 'F[PiezaYaw-2:-:PiezaRoll3-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [0 0 0];  % cm
smiData.RigidTransform(35).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(35).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(35).ID = 'B[faninferior-1:-:Piezamotor-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [-5.0404125317982107e-14 5.9999999999999876 -2.2204460492503131e-16];  % cm
smiData.RigidTransform(36).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(36).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(36).ID = 'F[faninferior-1:-:Piezamotor-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [0 7.4999999999999982 0];  % cm
smiData.RigidTransform(37).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(37).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(37).ID = 'B[Piezamotor-1:-:faninferior-7]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [2.4674706722294104e-13 0.69999999999998774 -5.0236204085507552e-13];  % cm
smiData.RigidTransform(38).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(38).axis = [-0.57735026918962584 -0.57735026918962562 -0.57735026918962595];
smiData.RigidTransform(38).ID = 'F[Piezamotor-1:-:faninferior-7]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [0 0 0];  % cm
smiData.RigidTransform(39).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(39).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(39).ID = 'B[faninferior-4:-:Piezamotor-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [-6.2438942904918804e-13 6.0000000000000471 -1.9473311851925246e-13];  % cm
smiData.RigidTransform(40).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(40).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(40).ID = 'F[faninferior-4:-:Piezamotor-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [0 7.5000000000000036 0];  % cm
smiData.RigidTransform(41).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(41).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(41).ID = 'B[Piezamotor-2:-:faninferior-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [-2.8725632983395144e-12 0.7000000000000477 -3.6368408284914722e-12];  % cm
smiData.RigidTransform(42).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(42).axis = [-0.57735026918962584 -0.57735026918962562 -0.57735026918962584];
smiData.RigidTransform(42).ID = 'F[Piezamotor-2:-:faninferior-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [0 0 0];  % cm
smiData.RigidTransform(43).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(43).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(43).ID = 'B[faninferior-2:-:Piezamotor-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [3.9968028886505635e-15 6.0000000000000533 -1.936228954946273e-13];  % cm
smiData.RigidTransform(44).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(44).axis = [0.57735026918962562 -0.57735026918962584 0.57735026918962595];
smiData.RigidTransform(44).ID = 'F[faninferior-2:-:Piezamotor-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [0 7.5000000000000009 0];  % cm
smiData.RigidTransform(45).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(45).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(45).ID = 'B[Piezamotor-3:-:faninferior-8]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [1.4061252162633764e-12 0.70000000000004348 -2.0178997361952611e-12];  % cm
smiData.RigidTransform(46).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(46).axis = [-0.57735026918962606 -0.57735026918962495 -0.57735026918962618];
smiData.RigidTransform(46).ID = 'F[Piezamotor-3:-:faninferior-8]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [0 0 0];  % cm
smiData.RigidTransform(47).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(47).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(47).ID = 'B[faninferior-3:-:Piezamotor-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [7.5495165674510645e-15 6.0000000000000053 -1.609823385706477e-14];  % cm
smiData.RigidTransform(48).angle = 2.0943951023931966;  % rad
smiData.RigidTransform(48).axis = [0.57735026918962606 -0.57735026918962573 0.5773502691896254];
smiData.RigidTransform(48).ID = 'F[faninferior-3:-:Piezamotor-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [0 7.5000000000000036 0];  % cm
smiData.RigidTransform(49).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(49).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(49).ID = 'B[Piezamotor-4:-:faninferior-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [7.0099481774832384e-13 0.70000000000000484 -1.5448198276146741e-12];  % cm
smiData.RigidTransform(50).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(50).axis = [-0.57735026918962595 -0.57735026918962573 -0.57735026918962562];
smiData.RigidTransform(50).ID = 'F[Piezamotor-4:-:faninferior-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(51).translation = [0.99999999999999956 0.35000000000000031 -1.0000000000000009];  % cm
smiData.RigidTransform(51).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(51).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(51).ID = 'B[ParteU-1:-:Yaw-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(52).translation = [1.000000000000004 28.35000000000003 -0.99999999999999245];  % cm
smiData.RigidTransform(52).angle = 2.0943951023931757;  % rad
smiData.RigidTransform(52).axis = [0.57735026918963883 -0.57735026918961918 0.57735026918961918];
smiData.RigidTransform(52).ID = 'F[ParteU-1:-:Yaw-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(53).translation = [0 -7.7000000000000011 0];  % cm
smiData.RigidTransform(53).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(53).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(53).ID = 'B[Base2-1:-:Yaw-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(54).translation = [1.1675113245271983e-15 -1.7763568394002505e-15 -6.2974347458781475e-15];  % cm
smiData.RigidTransform(54).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(54).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962562];
smiData.RigidTransform(54).ID = 'F[Base2-1:-:Yaw-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(55).translation = [0 -0.59999999999999776 0];  % cm
smiData.RigidTransform(55).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(55).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(55).ID = 'B[faninferior-2:-:fan-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(56).translation = [-9.2648111404969313e-14 -1.0500000000000267 1.7760792836440942e-13];  % cm
smiData.RigidTransform(56).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(56).axis = [-0.57735026918962562 -0.57735026918962573 -0.57735026918962595];
smiData.RigidTransform(56).ID = 'F[faninferior-2:-:fan-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(57).translation = [0 0.35000000000000309 0];  % cm
smiData.RigidTransform(57).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(57).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(57).ID = 'B[fan-4:-:Piezamotor-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(58).translation = [4.9737991503207013e-14 6.8000000000000824 2.2204460492503131e-15];  % cm
smiData.RigidTransform(58).angle = 2.0943951023931948;  % rad
smiData.RigidTransform(58).axis = [0.57735026918962562 -0.57735026918962618 0.57735026918962562];
smiData.RigidTransform(58).ID = 'F[fan-4:-:Piezamotor-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(59).translation = [0 -0.59999999999999776 0];  % cm
smiData.RigidTransform(59).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(59).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(59).ID = 'B[faninferior-3:-:fan-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(60).translation = [1.6986412276764895e-14 -1.0499999999999918 6.7168492989821971e-15];  % cm
smiData.RigidTransform(60).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(60).axis = [-0.57735026918962584 -0.57735026918962506 -0.5773502691896264];
smiData.RigidTransform(60).ID = 'F[faninferior-3:-:fan-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(61).translation = [0 0.35000000000000031 0];  % cm
smiData.RigidTransform(61).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(61).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(61).ID = 'B[fan-5:-:Piezamotor-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(62).translation = [-1.2878587085651816e-14 6.8000000000000007 -1.7319479184152442e-14];  % cm
smiData.RigidTransform(62).angle = 2.0943951023931966;  % rad
smiData.RigidTransform(62).axis = [0.57735026918962618 -0.57735026918962518 0.57735026918962595];
smiData.RigidTransform(62).ID = 'F[fan-5:-:Piezamotor-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(63).translation = [0 -0.60000000000000331 0];  % cm
smiData.RigidTransform(63).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(63).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(63).ID = 'B[faninferior-1:-:fan-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(64).translation = [-4.4297898682543746e-14 -1.050000000000068 4.1078251911130792e-15];  % cm
smiData.RigidTransform(64).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(64).axis = [-0.57735026918962562 -0.57735026918962584 -0.57735026918962595];
smiData.RigidTransform(64).ID = 'F[faninferior-1:-:fan-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(65).translation = [0 0.35000000000000031 0];  % cm
smiData.RigidTransform(65).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(65).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(65).ID = 'B[fan-6:-:Piezamotor-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(66).translation = [-5.3290705182007514e-15 6.8000000000000513 1.3322676295501878e-15];  % cm
smiData.RigidTransform(66).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(66).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(66).ID = 'F[fan-6:-:Piezamotor-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(67).translation = [0 -0.60000000000000053 0];  % cm
smiData.RigidTransform(67).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(67).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(67).ID = 'B[faninferior-4:-:fan-7]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(68).translation = [4.1866510258614653e-13 -1.0500000000000089 -5.0026649489609554e-13];  % cm
smiData.RigidTransform(68).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(68).axis = [-0.57735026918962584 -0.57735026918962595 -0.57735026918962562];
smiData.RigidTransform(68).ID = 'F[faninferior-4:-:fan-7]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(69).translation = [0 0.34999999999999476 0];  % cm
smiData.RigidTransform(69).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(69).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(69).ID = 'B[fan-7:-:Piezamotor-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(70).translation = [3.1086244689504383e-15 6.8000000000000549 -1.7541523789077473e-14];  % cm
smiData.RigidTransform(70).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(70).axis = [0.57735026918962573 -0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(70).ID = 'F[fan-7:-:Piezamotor-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(71).translation = [-3.42093375572103 -1.9031814783527092 18.400000000000009];  % cm
smiData.RigidTransform(71).angle = 0;  % rad
smiData.RigidTransform(71).axis = [0 0 0];
smiData.RigidTransform(71).ID = 'RootGround[Base2-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(12).mass = 0.0;
smiData.Solid(12).CoM = [0.0 0.0 0.0];
smiData.Solid(12).MoI = [0.0 0.0 0.0];
smiData.Solid(12).PoI = [0.0 0.0 0.0];
smiData.Solid(12).color = [0.0 0.0 0.0];
smiData.Solid(12).opacity = 0.0;
smiData.Solid(12).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.036335611738178168;  % kg
smiData.Solid(1).CoM = [0.00027654773846715996 0.25461303065486279 -0.00053005847011368531];  % cm
smiData.Solid(1).MoI = [1.3702261716629833 2.7357840038795689 1.370226626483759];  % kg*cm^2
smiData.Solid(1).PoI = [3.7608871751990833e-06 6.810478311545392e-08 -1.2745574998571098e-06];  % kg*cm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'faninferior*:*Predeterminado';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.042985871634080915;  % kg
smiData.Solid(2).CoM = [0 4.9923171854795623 0.0012413350878571806];  % cm
smiData.Solid(2).MoI = [0.74603720867395973 0.45539465488268427 1.0862787768279873];  % kg*cm^2
smiData.Solid(2).PoI = [-6.3395282310932253e-05 0 0];  % kg*cm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'ParteU*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.035744752027446085;  % kg
smiData.Solid(3).CoM = [0 0.49999999999999994 0.53425458643853152];  % cm
smiData.Solid(3).MoI = [0.12861616092851327 0.2134896118732672 0.090830909615994937];  % kg*cm^2
smiData.Solid(3).PoI = [0 0 0];  % kg*cm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'PiezaYaw2*:*Predeterminado';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.0077609955391902694;  % kg
smiData.Solid(4).CoM = [0 0.009454710946552097 0];  % cm
smiData.Solid(4).MoI = [0.00063518245862874358 0.34178867928456641 0.34170082023057086];  % kg*cm^2
smiData.Solid(4).PoI = [0 0 0];  % kg*cm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'PiezaRoll2*:*Predeterminado';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.03360145582492137;  % kg
smiData.Solid(5).CoM = [-0.0012392002307909887 -0.18501333007754578 0.02344639556969948];  % cm
smiData.Solid(5).MoI = [0.092620266088120767 0.055091015285235245 0.11686154004140827];  % kg*cm^2
smiData.Solid(5).PoI = [-0.0019183839177232757 6.0078869307734117e-05 0.00010139135401522537];  % kg*cm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'PiezaRoll3*:*Predeterminado';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.26604615494724831;  % kg
smiData.Solid(6).CoM = [1.1304190177446553e-11 1.4648403919685753 5.3129042991860031e-11];  % cm
smiData.Solid(6).MoI = [6.9161658605272853 10.647704200020728 6.9161658605272827];  % kg*cm^2
smiData.Solid(6).PoI = [-5.9862407078679456e-11 0 -1.2737088286286288e-11];  % kg*cm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'base*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.057220451951481323;  % kg
smiData.Solid(7).CoM = [-0.19883676173241069 22.595532401051155 -0.0017316691236569863];  % cm
smiData.Solid(7).MoI = [3.1381210757006954 0.10588124016354557 3.1772601373274556];  % kg*cm^2
smiData.Solid(7).PoI = [0.000363395348679919 -0.00020324338592853255 0.041726420696095272];  % kg*cm^2
smiData.Solid(7).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'Yaw*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.00057362340261896084;  % kg
smiData.Solid(8).CoM = [0 0 0];  % cm
smiData.Solid(8).MoI = [0.00018634634253579158 2.7562604495841067e-05 0.00018634634253579158];  % kg*cm^2
smiData.Solid(8).PoI = [0 0 0];  % kg*cm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'PiezaYaw*:*Predeterminado';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 0.0022241444236159457;  % kg
smiData.Solid(9).CoM = [0 0.079983107794168271 0];  % cm
smiData.Solid(9).MoI = [0.036478369276890722 0.036679356516004152 0.00034957002070081834];  % kg*cm^2
smiData.Solid(9).PoI = [0 0.00036632427967073829 0];  % kg*cm^2
smiData.Solid(9).color = [0.82352941176470584 0.82352941176470584 0.82352941176470584];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = 'fan*:*Predeterminado';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 0.82781927585448722;  % kg
smiData.Solid(10).CoM = [0.096579072589510512 0.40000000000000002 0.10990347109929588];  % cm
smiData.Solid(10).MoI = [145.4137425543384 288.26298531332651 142.93754347347306];  % kg*cm^2
smiData.Solid(10).PoI = [0 -0.05428096580218246 0];  % kg*cm^2
smiData.Solid(10).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = 'Superior*:*Predeterminado';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 0.33997834079568734;  % kg
smiData.Solid(11).CoM = [-0.027379064280400479 0.79438277538317981 -0.0057464842066370717];  % cm
smiData.Solid(11).MoI = [10.421630849929716 3.261902538831047 10.45205767015552];  % kg*cm^2
smiData.Solid(11).PoI = [-0.01590873481142635 5.2687384658526784e-05 0.012342866580432276];  % kg*cm^2
smiData.Solid(11).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = 'Base2*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 0.043055440198106351;  % kg
smiData.Solid(12).CoM = [2.9985567966448763e-05 3.021292535113107 2.9985567966404321e-05];  % cm
smiData.Solid(12).MoI = [0.15987103694481189 0.047909678942970636 0.15987103694481189];  % kg*cm^2
smiData.Solid(12).PoI = [4.9025190889119807e-06 -9.6824265866672827e-07 4.9025190889149428e-06];  % kg*cm^2
smiData.Solid(12).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = 'Piezamotor*:*Predeterminado';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(11).Rz.Pos = 0.0;
smiData.CylindricalJoint(11).Pz.Pos = 0.0;
smiData.CylindricalJoint(11).ID = '';

smiData.CylindricalJoint(1).Rz.Pos = -119.71996449359706;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(1).ID = '[ParteU-1:-:PiezaYaw-1]';

smiData.CylindricalJoint(2).Rz.Pos = -64.994929350077186;  % deg
smiData.CylindricalJoint(2).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(2).ID = '[ParteU-1:-:PiezaYaw-2]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(3).Rz.Pos = 135.88241395296802;  % deg
smiData.CylindricalJoint(3).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(3).ID = '[PiezaYaw-2:-:PiezaRoll3-2]';

smiData.CylindricalJoint(4).Rz.Pos = 101.355274008463;  % deg
smiData.CylindricalJoint(4).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(4).ID = '[Piezamotor-1:-:faninferior-7]';

smiData.CylindricalJoint(5).Rz.Pos = -122.43491163306328;  % deg
smiData.CylindricalJoint(5).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(5).ID = '[Piezamotor-2:-:faninferior-5]';

smiData.CylindricalJoint(6).Rz.Pos = -157.33995086403073;  % deg
smiData.CylindricalJoint(6).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(6).ID = '[Piezamotor-3:-:faninferior-8]';

smiData.CylindricalJoint(7).Rz.Pos = -37.777587988638437;  % deg
smiData.CylindricalJoint(7).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(7).ID = '[Piezamotor-4:-:faninferior-6]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(8).Rz.Pos = -139.41839892473322;  % deg
smiData.CylindricalJoint(8).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(8).ID = '[fan-4:-:Piezamotor-3]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(9).Rz.Pos = 19.694970023332321;  % deg
smiData.CylindricalJoint(9).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(9).ID = '[fan-5:-:Piezamotor-4]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(10).Rz.Pos = -8.4461567468868903;  % deg
smiData.CylindricalJoint(10).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(10).ID = '[fan-6:-:Piezamotor-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(11).Rz.Pos = 114.13177986807301;  % deg
smiData.CylindricalJoint(11).Pz.Pos = 0;  % cm
smiData.CylindricalJoint(11).ID = '[fan-7:-:Piezamotor-2]';


%Initialize the PlanarJoint structure array by filling in null values.
smiData.PlanarJoint(5).Rz.Pos = 0.0;
smiData.PlanarJoint(5).Px.Pos = 0.0;
smiData.PlanarJoint(5).Py.Pos = 0.0;
smiData.PlanarJoint(5).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(1).Rz.Pos = 169.39255090351207;  % deg
smiData.PlanarJoint(1).Px.Pos = 0;  % cm
smiData.PlanarJoint(1).Py.Pos = 0;  % cm
smiData.PlanarJoint(1).ID = '[PiezaRoll3-2:-:PiezaYaw-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(2).Rz.Pos = -101.35444920008145;  % deg
smiData.PlanarJoint(2).Px.Pos = 0;  % cm
smiData.PlanarJoint(2).Py.Pos = 0;  % cm
smiData.PlanarJoint(2).ID = '[faninferior-1:-:Piezamotor-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(3).Rz.Pos = -93.570349777179572;  % deg
smiData.PlanarJoint(3).Px.Pos = 0;  % cm
smiData.PlanarJoint(3).Py.Pos = 0;  % cm
smiData.PlanarJoint(3).ID = '[faninferior-4:-:Piezamotor-2]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(4).Rz.Pos = 157.34077567241346;  % deg
smiData.PlanarJoint(4).Px.Pos = 0;  % cm
smiData.PlanarJoint(4).Py.Pos = 0;  % cm
smiData.PlanarJoint(4).ID = '[faninferior-2:-:Piezamotor-3]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(5).Rz.Pos = -34.224839011846008;  % deg
smiData.PlanarJoint(5).Px.Pos = 0;  % cm
smiData.PlanarJoint(5).Py.Pos = 0;  % cm
smiData.PlanarJoint(5).ID = '[faninferior-3:-:Piezamotor-4]';


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(14).Rz.Pos = 0.0;
smiData.RevoluteJoint(14).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 70.887484602890851;  % deg
smiData.RevoluteJoint(1).ID = '[ParteU-1:-:PiezaRoll3-2]';

smiData.RevoluteJoint(2).Rz.Pos = -173.84159175212741;  % deg
smiData.RevoluteJoint(2).ID = '[PiezaRoll3-2:-:PiezaRoll2-2]';

smiData.RevoluteJoint(3).Rz.Pos = 66.977676132273601;  % deg
smiData.RevoluteJoint(3).ID = '[Superior-1:-:faninferior-1]';

smiData.RevoluteJoint(4).Rz.Pos = 79.42176526690173;  % deg
smiData.RevoluteJoint(4).ID = '[Superior-1:-:faninferior-2]';

smiData.RevoluteJoint(5).Rz.Pos = 20.742572837568847;  % deg
smiData.RevoluteJoint(5).ID = '[Superior-1:-:faninferior-3]';

smiData.RevoluteJoint(6).Rz.Pos = 0.00082480838157330931;  % deg
smiData.RevoluteJoint(6).ID = '[faninferior-1:-:faninferior-7]';

smiData.RevoluteJoint(7).Rz.Pos = 0.00082480838274693376;  % deg
smiData.RevoluteJoint(7).ID = '[faninferior-2:-:faninferior-8]';

smiData.RevoluteJoint(8).Rz.Pos = -72.00242700048446;  % deg
smiData.RevoluteJoint(8).ID = '[faninferior-3:-:faninferior-6]';

smiData.RevoluteJoint(9).Rz.Pos = 143.99473858975716;  % deg
smiData.RevoluteJoint(9).ID = '[faninferior-4:-:faninferior-5]';

smiData.RevoluteJoint(10).Rz.Pos = -45.806846973232808;  % deg
smiData.RevoluteJoint(10).ID = '[Base2-1:-:Yaw-1]';

smiData.RevoluteJoint(11).Rz.Pos = 63.240825402853318;  % deg
smiData.RevoluteJoint(11).ID = '[faninferior-2:-:fan-4]';

smiData.RevoluteJoint(12).Rz.Pos = 53.919809035178304;  % deg
smiData.RevoluteJoint(12).ID = '[faninferior-3:-:fan-5]';

smiData.RevoluteJoint(13).Rz.Pos = 92.908292453194548;  % deg
smiData.RevoluteJoint(13).ID = '[faninferior-1:-:fan-6]';

smiData.RevoluteJoint(14).Rz.Pos = -152.29787035474743;  % deg
smiData.RevoluteJoint(14).ID = '[faninferior-4:-:fan-7]';

